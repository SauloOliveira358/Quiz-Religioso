package com.example.showdomilhao;

public class Dados {
    public static final String NOME = "Nome";
    public static final String PONTUACAO = "Pontuação";
    public static final String ARQUIVO_USUARIO = "Arquivo Usuario";

}
